console.log("Teacher's Day website is connected!");
